# breakout_strategy.py
from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class BreakoutBTCStrategy(IStrategy):
    """
    BTC/USDT Breakout Strategy based on:
    - Resistance breakout for long positions
    - Support breakout for short positions
    - MACD and RSI for confirmation
    """

    # Minimal ROI and stoploss
    minimal_roi = {"0": 0.05}
    stoploss = -0.03  # adjustable
    timeframe = '5m'

    # Strategy parameters
    long_entry_price = 117500
    short_entry_price = 114400
    long_stoploss = 116000
    short_stoploss = 115500
    long_targets = [118000, 119000, 120000]
    short_targets = [113000, 112000, 111000]

    def populate_indicators(self, df: DataFrame, metadata: dict) -> DataFrame:
        # RSI
        df['rsi'] = ta.RSI(df, timeperiod=14)
        
        # MACD
        macd = ta.MACD(df)
        df['macd'] = macd['macd']
        df['macd_signal'] = macd['macdsignal']
        
        # Moving averages
        df['ma50'] = ta.SMA(df, timeperiod=50)
        df['ma200'] = ta.SMA(df, timeperiod=200)

        return df

    def populate_buy_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        """
        Buy when price breaks above long_entry_price and confirmed by MACD/RSI
        """
        df.loc[
            (df['close'] > self.long_entry_price) &          # breakout above resistance
            (df['macd'] > df['macd_signal']) &              # bullish MACD
            (df['rsi'] < 80),                               # not extremely overbought
            'buy'] = 1
        return df

    def populate_sell_trend(self, df: DataFrame, metadata: dict) -> DataFrame:
        """
        Sell when price breaks below short_entry_price and confirmed by MACD/RSI
        """
        df.loc[
            (df['close'] < self.short_entry_price) &        # breakout below support
            (df['macd'] < df['macd_signal']) &              # bearish MACD
            (df['rsi'] > 20),                               # not extremely oversold
            'sell'] = 1
        return df
